import background_V4_3 as bg

bg.inicializar()


while bg.cuenta_vidas() == True:

   
    bg.disparar_player()

    bg.disparar_maquina()
    

   
    

