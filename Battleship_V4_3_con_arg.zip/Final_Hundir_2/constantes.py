tamaños = [1,1,1,1,2,2,2,3,3,4]
direccion = ['N','S','E','W']